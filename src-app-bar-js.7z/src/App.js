import React, {Component} from 'react';
import AppBar from '@material-ui/core/AppBar';
import ArduinoButton from 'components/ArduinoButton';
import TuneDialog from 'components/TuneDialog';
import Grid from '@material-ui/core/Grid';
import Box from "@material-ui/core/Box";
import Led from 'components/Led';
//import { bottom, zIndex } from '@material-ui/system';
import 'App.css';

const fs = require('fs-extra')
const os = require('os');

class App extends Component {
    constructor(props) {
        super(props);

        this.state = {
            settings: {
                name: 'Fog Machine',
                arduinoIpAddress: '',
                T1: 10,
                N: 2,
                T2: 5,
                T3: 5
            },
            machine: {
                power: 1,
                fog: 0
            },
            status: "",
        };

        //console.log(os.homedir());
        const settings_path = os.homedir() + "\\AppData\\Local\\fog_settings.json"

        if (fs.existsSync(settings_path)) {
            const settings = fs.readJsonSync(settings_path, {throws: false})
            if (settings) {
                //console.log(settings)
                this.state.settings = settings;
            }
        }

        if (!this.state.settings.arduinoIpAddress) {
            this.state.status = "Arduino IP address is missing";
        }

        nw.Window.get().showDevTools(); // while debugging

        console.log(nw.Window.get().height);

        const win = nw.Window.get().window;
        console.log(win);

        this.extraHeight = nw.Window.get().height - win.innerHeight;
        console.log(this.extraHeight);

        console.log(nw.Window.get().height - this.extraHeight);
        //this.props.height = nw.Window.get().height - this.extraHeight;

    }

    componentDidMount() {
        const el = document.getElementById('root');
        console.log(el);
        console.log('root', el.style.height);
        console.log('nw', nw.Window.get().height - this.extraHeight);
        //el.style.height = nw.Window.get().height - this.extraHeight;

        const win = nw.Window.get().window;
        win.addEventListener('resize', (e) => {
            console.log('resized', e.target.innerHeight);
            const el = document.getElementById('panel');
            console.log('panel', el.style.height);
            const h = e.target.innerHeight - this.extraHeight;
            el.style.height = h.toString()  + "px";
        });
    }

    componentDidUpdate(prevProps, prevState, snapshot) {

        console.log(nw.Window.get().height - this.extraHeight);
    }

    handlePowerOffClicked(e) {
        console.log('handlePowerOffClicked');
        const prevState = this.state
        prevState.machine.power = 0;
        this.setState(prevState); // => render
    }

    handlePowerOnClicked(e) {
        console.log('handlePowerOnClicked');
        const prevState = this.state
        prevState.machine.power = 1;
        this.setState(prevState); // => render
    }

    render() {
        return (
            <div className="App">
                <header className="App-header">
                    {this.state.settings.name}
                </header>
                <div className="App-panel" id="panel">
                    <Grid container spacing={2} alignItems="center">
                        <Grid item xs={6}>
                            <Led className="Led"
                                 alt="power"
                                 label="POWER"
                                 state={this.state.machine.power}
                            />
                        </Grid>
                        <Grid item xs={6}>
                            <Led className="Led"
                                 alt="fog"
                                 label="FOG"
                                 state={this.state.machine.fog}
                            />
                        </Grid>
                    </Grid>
                    <Grid container spacing={2} alignItems="center">
                        <Grid item xs={6}>
                            <p></p>
                        </Grid>
                    </Grid>
                    <Grid container spacing={2} alignItems="center">
                        <Grid item xs={6}>
                            <ArduinoButton state={this.state}
                                           onClick={this.handlePowerOnClicked.bind(this)}>
                                POWER ON
                            </ArduinoButton>
                        </Grid>
                        <Grid item xs={6}>
                            <ArduinoButton state={this.state}
                                           onClick={this.handlePowerOffClicked.bind(this)}>
                                POWER OFF
                            </ArduinoButton>
                        </Grid>
                    </Grid>
                    <Grid container spacing={2} alignItems="center">
                        <Grid item xs={6}>
                            <p></p>
                        </Grid>
                    </Grid>
                    <Grid container spacing={2} padding={10} alignItems="center">
                        <Grid item xs={6}>
                            <ArduinoButton state={this.state}
                                           onClick={() => alert(this.state.settings.arduinoIpAddress)}>
                                SPIT ON
                            </ArduinoButton>
                        </Grid>
                        <Grid item xs={6}>
                            <ArduinoButton state={this.state}
                                           onClick={() => alert(this.state.settings.arduinoIpAddress)}>
                                SPIT OFF
                            </ArduinoButton>
                        </Grid>
                    </Grid>
                    <Grid container spacing={2} alignItems="center">
                        <Grid item xs={6}>
                            <p></p>
                        </Grid>
                    </Grid>
                    <Grid container spacing={2} padding={10} alignItems="center">
                        <Grid item xs={6}>
                            <TuneDialog
                                settings={this.state.settings}
                                onChange={(e) => {
                                    const prevState = this.state;
                                    if (this.state.settings.arduinoIpAddress) {
                                        prevState.status = "";
                                    } else {
                                        prevState.status = "Arduino IP address is missing";
                                    }
                                    this.setState(prevState)
                                }}
                            />
                        </Grid>
                    </Grid>
                </div>
                <React.Fragment>
                <AppBar color="primary" className="App-bar">
                    {this.state.status}
                </AppBar>
                </React.Fragment>
                <Box className="App-status-bar">
                    App-status-bar
                </Box>
            </div>
        );
    }
}

export default App;
